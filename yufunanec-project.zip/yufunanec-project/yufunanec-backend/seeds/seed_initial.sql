-- Sample products
INSERT INTO products (sku, name, description, category, price, color, size, stock, image_url)
VALUES
('KOL-001','Morobe Meri Blouse (Red)','Hand-sewn Meri blouse with traditional motifs.','Kolos',120.00,'Red','M',6,''),
('GWN-002','Traditional Gown (Blue)','Formal gown inspired by PNG patterns.','Gowns',220.00,'Blue','L',3,''),
('TSH-003','YUFUNANEC T-Shirt','Cotton t-shirt with print.','Shirts',40.00,'White','S',15,''),
('KOL-004','Lae Handwoven Kolu Skirt','Handwoven with natural dyes.','Kolos',150.00,'Brown','M',5,''),
('ACC-101','Beaded Necklace (Set)','Traditional beaded necklace handcrafted locally.','Accessories',25.00,'Multi','One size',30,'');
