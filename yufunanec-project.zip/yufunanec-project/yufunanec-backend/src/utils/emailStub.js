function sendEmail(to, subject, body) {
  console.log('--- Email stub ---');
  console.log(`To: ${to}\nSubject: ${subject}\n\n${body}\n`);
}
module.exports = { sendEmail };
