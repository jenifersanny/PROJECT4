const API = "http://localhost:4000/api";
const token = localStorage.getItem("token");

// -------------------- Auth ----------------------
async function customerLogin(e) {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const res = await fetch(`${API}/auth/login`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if(data.token) {
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));
    window.location.href = "index.html";
  } else alert(data.error || "Login failed");
}

async function customerRegister(e) {
  e.preventDefault();
  const body = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value,
    phone: document.getElementById("phone").value,
    address: document.getElementById("address").value
  };
  const res = await fetch(`${API}/auth/register`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if(data.user) {
    alert("Registration successful. Please login.");
    window.location.href = "login.html";
  } else alert(data.error || "Registration failed");
}

function setupAuthLinks() {
  const user = localStorage.getItem("user");
  if(user) {
    document.getElementById("loginLink").classList.add("hidden");
    document.getElementById("logoutBtn").classList.remove("hidden");
    document.getElementById("logoutBtn").onclick = () => {
      localStorage.clear();
      window.location.href = "login.html";
    };
  }
}

// -------------------- Shop ----------------------
async function loadProducts() {
  const res = await fetch(`${API}/products`);
  const data = await res.json();
  const container = document.getElementById("products");
  container.innerHTML = "";
  data.products.forEach(p => {
    const div = document.createElement("div");
    div.className = "card";
    div.innerHTML = `
      <h3>${p.name}</h3>
      <p>K ${p.price}</p>
      <button onclick="addToCart(${p.product_id})">Add to Cart</button>
    `;
    container.appendChild(div);
  });
}

async function addToCart(productId) {
  if(!token) { alert("Login required"); return; }
  await fetch(`${API}/cart/items`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
    body: JSON.stringify({ product_id: productId, quantity: 1 })
  });
  updateCartCount();
  alert("Added to cart!");
}

// -------------------- Cart ----------------------
async function loadCart() {
  const res = await fetch(`${API}/cart`, {
    headers: { "Authorization": "Bearer " + token }
  });
  const data = await res.json();
  const div = document.getElementById("cartItems");
  let total = 0;
  div.innerHTML = "";
  data.items.forEach(i => {
    total += i.price * i.quantity;
    div.innerHTML += `<p>${i.name} - K ${i.price} x ${i.quantity}</p>`;
  });
  document.getElementById("total").innerText = total;
}

async function checkout() {
  const res = await fetch(`${API}/orders`, {
    method: "POST",
    headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
    body: JSON.stringify({ payment_method: "mobile_wallet" })
  });
  const data = await res.json();
  if(data.order_id) {
    alert("Order placed successfully!");
    window.location.href = "orders.html";
  } else alert(data.error || "Checkout failed");
}

async function updateCartCount() {
  if(!token) return;
  const res = await fetch(`${API}/cart`, { headers: { "Authorization": "Bearer " + token }});
  const data = await res.json();
  document.getElementById("cartCount").innerText = data.items?.length || 0;
}

// -------------------- Orders ----------------------
async function loadOrders() {
  const res = await fetch(`${API}/orders`, {
    headers: { "Authorization": "Bearer " + token }
  });
  const data = await res.json();
  const div = document.getElementById("orders");
  div.innerHTML = "";
  data.orders.forEach(o => {
    div.innerHTML += `<p>Order #${o.order_id} - K ${o.total_amount} - ${o.status}</p>`;
  });
}
function toggleMenu() {
  document.getElementById("navMenu").classList.toggle("show");
}

