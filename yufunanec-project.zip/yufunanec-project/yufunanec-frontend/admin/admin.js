const API = "http://localhost:4000/api";
const token = localStorage.getItem("adminToken");

// -------------------- Auth ----------------------
async function adminLogin(e) {
  e.preventDefault();
  const email = document.getElementById("email").value;
  const password = document.getElementById("password").value;
  const res = await fetch(`${API}/auth/admin/login`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });
  const data = await res.json();
  if(data.token) {
    localStorage.setItem("adminToken", data.token);
    window.location.href = "index.html";
  } else alert(data.error || "Login failed");
}

async function adminRegister(e) {
  e.preventDefault();
  const body = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    password: document.getElementById("password").value
  };
  const res = await fetch(`${API}/auth/admin/register`, {
    method: "POST", headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if(data.admin) {
    alert("Registration successful. Please login.");
    window.location.href = "login.html";
  } else alert(data.error || "Registration failed");
}

function logout() {
  localStorage.removeItem("adminToken");
  window.location.href = "login.html";
}

// -------------------- Dashboard ----------------------
function showPage(page) {
  if(!token) { window.location.href = "login.html"; return; }
  if(page === "products") loadProducts();
  if(page === "orders") loadOrders();
  if(page === "payments") loadPayments();
  if(page === "staff") loadStaff();
}

// -------------------- Products ----------------------
async function loadProducts() {
  const res = await fetch(`${API}/products`);
  const data = await res.json();
  let html = `<h2>Products</h2>
    <button onclick="showAddProduct()">Add Product</button>
    <table><tr><th>Name</th><th>Price</th><th>Stock</th><th>Actions</th></tr>`;
  data.products.forEach(p => {
    html += `<tr>
      <td>${p.name}</td>
      <td>K ${p.price}</td>
      <td>${p.stock}</td>
      <td>
        <button class="small" onclick="deleteProduct(${p.product_id})">Delete</button>
      </td>
    </tr>`;
  });
  html += "</table>";
  document.getElementById("content").innerHTML = html;
}

async function showAddProduct() {
  document.getElementById("content").innerHTML = `
    <h2>Add Product</h2>
    <form id="addForm">
      <input id="name" placeholder="Name" required/><br/>
      <input id="sku" placeholder="SKU"/><br/>
      <input id="price" type="number" placeholder="Price" required/><br/>
      <input id="stock" type="number" placeholder="Stock" required/><br/>
      <button type="submit">Save</button>
    </form>
  `;
  document.getElementById("addForm").onsubmit = async (e) => {
    e.preventDefault();
    const body = {
      name: document.getElementById("name").value,
      sku: document.getElementById("sku").value,
      price: Number(document.getElementById("price").value),
      stock: Number(document.getElementById("stock").value)
    };
    const res = await fetch(`${API}/products`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
      body: JSON.stringify(body)
    });
    if(res.ok) { alert("Product added"); loadProducts(); }
    else alert("Error adding product");
  };
}

async function deleteProduct(id) {
  if(!confirm("Delete this product?")) return;
  await fetch(`${API}/products/${id}`, {
    method: "DELETE", headers: { "Authorization": "Bearer " + token }
  });
  loadProducts();
}

// -------------------- Orders ----------------------
async function loadOrders() {
  const res = await fetch(`${API}/orders/all`, { headers: { "Authorization": "Bearer " + token } });
  const data = await res.json();
  let html = "<h2>Orders</h2><table><tr><th>ID</th><th>Customer</th><th>Total</th><th>Status</th></tr>";
  data.orders.forEach(o => {
    html += `<tr><td>${o.order_id}</td><td>${o.customer_email}</td><td>K ${o.total_amount}</td><td>${o.status}</td></tr>`;
  });
  html += "</table>";
  document.getElementById("content").innerHTML = html;
}

// -------------------- Payments ----------------------
async function loadPayments() {
  const res = await fetch(`${API}/payments`, { headers: { "Authorization": "Bearer " + token } });
  const data = await res.json();
  let html = "<h2>Payments</h2><table><tr><th>ID</th><th>Customer</th><th>Amount</th><th>Status</th></tr>";
  data.payments.forEach(p => {
    html += `<tr><td>${p.payment_id}</td><td>${p.customer_email}</td><td>K ${p.amount}</td><td>${p.status}</td></tr>`;
  });
  html += "</table>";
  document.getElementById("content").innerHTML = html;
}

// -------------------- Staff ----------------------
async function loadStaff() {
  const res = await fetch(`${API}/staff`, { headers: { "Authorization": "Bearer " + token } });
  const data = await res.json();
  let html = `<h2>Staff</h2>
    <button onclick="showAddStaff()">Add Staff</button>
    <table><tr><th>Name</th><th>Email</th><th>Role</th><th>Actions</th></tr>`;
  data.staff.forEach(s => {
    html += `<tr><td>${s.name}</td><td>${s.email}</td><td>${s.role}</td>
      <td><button class="small" onclick="deleteStaff(${s.staff_id})">Delete</button></td></tr>`;
  });
  html += "</table>";
  document.getElementById("content").innerHTML = html;
}

function showAddStaff() {
  document.getElementById("content").innerHTML = `
    <h2>Add Staff</h2>
    <form id="staffForm">
      <input id="name" placeholder="Name" required/><br/>
      <input id="email" placeholder="Email"/><br/>
      <input id="role" placeholder="Role"/><br/>
      <button type="submit">Save</button>
    </form>
  `;
  document.getElementById("staffForm").onsubmit = async (e) => {
    e.preventDefault();
    const body = {
      name: document.getElementById("name").value,
      email: document.getElementById("email").value,
      role: document.getElementById("role").value
    };
    const res = await fetch(`${API}/staff`, {
      method: "POST",
      headers: { "Content-Type": "application/json", "Authorization": "Bearer " + token },
      body: JSON.stringify(body)
    });
    if(res.ok) { alert("Staff added"); loadStaff(); }
    else alert("Error adding staff");
  };
}

async function deleteStaff(id) {
  if(!confirm("Delete staff?")) return;
  await fetch(`${API}/staff/${id}`, {
    method: "DELETE", headers: { "Authorization": "Bearer " + token }
  });
  loadStaff();
}
function toggleMenu() {
  document.getElementById("navMenu").classList.toggle("show");
}

